from turtle import update
from unittest.mock import AsyncMockMixin
import pygame
import os
import Plax_BG
import char_animation_experim

pygame.init()
FPS = 60
SCREENWIDTH = 1344
SCREENHEIGHT = 756
screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
pygame.display.set_caption("City Escape")
clock = pygame.time.Clock()
os.chdir('City Escape\\')

# Game window
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

#GAM VAR
char_frame = (300, 150)
sx = 500 
sy = 500
width = 128
height = 128
vel = 5
isJump = False
jumpCount = 10
base_y = 200
sy = 0
left = False
right = False
walkCount = 0

#game loop
gravity = 0.5

level = 1
bg = Plax_BG.ParallaxBackground(level)
animation = char_animation_experim.Animation()
char_x = 300

current_direction = "IR"
last_direction = "IR"

class Button:
    
    def __init__(self, text, x, y, width, height):
        self.text = text
        self.rect = pygame.Rect(x, y, width, height)

    def draw(self, screen):
        font_path = 'City Escape\\confession.ttf'
        font_size = 48
        font = pygame.font.Font(font_path, font_size)
        pygame.draw.rect(screen, WHITE, self.rect)
        text_surface = font.render(self.text, True, BLACK)
        screen.blit(text_surface, (self.rect.x + (self.rect.width - text_surface.get_width()) // 2, self.rect.y + (self.rect.height - text_surface.get_height()) // 2))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

def title_screen():
    play_button = Button("PLAY", SCREENWIDTH // 2 - 100, SCREENHEIGHT // 2 - 50, 200, 100)
    exit_button = Button("QUIT", SCREENWIDTH // 2 - 100, SCREENHEIGHT // 2 + 70, 200, 100)

    while True:
        screen.fill(BLACK)
        play_button.draw(screen)
        exit_button.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.is_clicked(event.pos):
                    return
                if exit_button.is_clicked(event.pos):
                    pygame.quite()
                    return
        
        pygame.display.flip()
        clock.tick(FPS)

class Bullet:
    def __init__(self, x, y, direction):
        self.x = x
        self.y = y
        self.direction = direction
        self.speed = 10

        self.spritesheet = pygame.image.load('City Escapefire-trails\\bullet.jpg').convert_alpha()

        bullet_rect = pygame.Rect(1255, 365, 2488, 646)
        self.image = self.spritesheet.subsurface(bullet_rect)

    def update(self):
        if self.direction == "right":
            self.x += self.speed
        else:
            self.x -= self.speed

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
SHOOT_RIGHT_ANIM = "SR"
SHOOT_LEFT_ANIM = "SL"

isShooting = False

class AmmoPickup:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.image = pygame.image.load('City Escape\\collect\\ammo.png').convert_alpha()
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
        self.rect.topleft = (self.x, self.y)



def main_game_loop():
    global isJump, level, char_x, bg, sy, jumpCount, isShooting, shoot_start_time, health, ammo
    bg = Plax_BG.ParallaxBackground(level)
    ammo = 5
    ammo_pickup = AmmoPickup(1000, 250)
    health = 15
    health_images = []
    for i in range(16):
        image_path = f'City Escape\\Health\\Health{i}.png'
        health_images.append(pygame.image.load(image_path).convert_alpha())

    font_path = 'City Escape\\confession.ttf'
    font_size = 48
    font = pygame.font.Font(font_path, font_size)

    jumpCount = 10
    sy = 0
    bg = Plax_BG.ParallaxBackground(level)
    char_x = 300
    isJump = False
    isShooting = False
    run = True
    level = 1
    animation = char_animation_experim.Animation()
    bullets = []
    shoot_duration = 150
    shoot_start_time = 0
    ammo_pickup = AmmoPickup(600, 400)
    left = False
    right = False
    last_direction = "IR"
    

    while run:
        clock.tick(FPS)
        screen.fill((0, 0, 0))

        def display_health(screen, health):
            current_health_image = health_images[health] if health <= 15 else health_images[15]
            screen.blit(current_health_image, (SCREENWIDTH - current_health_image.get_width() - 10, 10))
        
        def display_level(screen, level):
            level_text = f"Level {level}"
            font_path = 'City Escape\\confession.ttf'
            font_size = 48
            font = pygame.font.Font(font_path, font_size)
            text_surface = font.render(level_text, True, (255, 255, 255))
            screen.blit(text_surface, (10, 10))

        def display_ammo_count(screen, ammo):
            ammo_text = font.render(f"Ammo: {ammo}", True, (255, 255, 255))
            screen.blit(ammo_text, (10, 50))
            
        player_rect = pygame.Rect(char_x, base_y + sy, width, height)

        if player_rect.colliderect(ammo_pickup.rect):
            ammo += 5
            ammo_pickup.x, ammo_pickup.y = -100, -100

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

               
        keys = pygame.key.get_pressed()
        idle_direction = "IR" if right else "IL"
        
        if keys[pygame.K_SPACE] and not isJump and ammo > 0:
            if not isShooting:
                isShooting = True
                shoot_start_time = pygame.time.get_ticks()
                last_direction = "SR" if last_direction is right else "SL"
                bullet = Bullet(char_x + (width // 2), base_y + sy + height // 2, last_direction) 
                bullets.append(bullet)
                ammo -= 1
                animation.is_shooting = True

        if isShooting:
            animation.update_animation(last_direction)    
            if animation.frame >= len(animation.animation_list[last_direction]) - 2:
                isShooting = False
                animation.is_shooting = False
        else:
            if not isJump:
                animation.update_animation(last_direction)
                        

            
            
           # else:
           #     if not isJump:
        animation.update_animation(last_direction)

        if keys[pygame.K_LEFT] and bg.scroll > 0:
            bg.update_scroll(-vel)
            last_direction = "WL"
            left = True
            right = False
        elif keys[pygame.K_RIGHT] and bg.scroll < 5000 - width - vel:
            bg.update_scroll(vel)
            last_direction = "WR"
            left = False
            right = True
        else:
            last_direction = idle_direction
        animation.update_animation(last_direction)

        if keys[pygame.K_UP]:
            isJump = True
            last_direction = "JR" if last_direction is right else "JL"

        if isJump:
            neg = 1 if jumpCount >= 0 else -1        
            sy -= (jumpCount ** 2) * 0.5 * neg
            jumpCount -= 1

            if jumpCount < -10:
                isJump = False
                jumpCount = 10
                sy = 0
        animation.update_animation(last_direction)
        if not isShooting:
            animation.update_animation(last_direction)                

        animation.draw(screen, last_direction, (char_x, base_y + sy))

        for bullet in bullets[:]:
            bullet.update()
            bullet.draw(screen)   
            if bullet.x < 0 or bullet.x > SCREENWIDTH:
                bullets.remove(bullet)

        if health <= 1:
            run = False
    
        if bg.scroll >= 5000 - 800:
            level += 1
            if level > 3:
                level = 1
            bg = Plax_BG.ParallaxBackground(level)
            char_x = 300
            bg.scroll = 0

        bg.draw_bg(screen)
        bg.draw_ground(screen)

        animation.draw(screen, last_direction, (350, base_y + sy))
        display_level(screen, level)
        display_health(screen, health)
        display_ammo_count(screen, ammo)
        pygame.display.flip()

        if health <= 1:
            print("GAME OVER!")
            run = False

        

    pass
            
if __name__ == "__main__":
    title_screen()
    main_game_loop()



pygame.quit(), 

'''
                        if not isJump:
                if keys[pygame.K_LEFT] and bg.scroll > 0:
                    bg.update_scroll(-vel)
                    last_direction = "WL"
                    left = True
                    right = False
                
                elif keys[pygame.K_RIGHT] and bg.scroll < 5000 - width - vel:


                if idle:
                    animation.update_animation(last_direction)
                else:
                    animation.update_animation("WR" if right else "WL")
            else:
                
                
                animation.update_animation(last_direction)

            if isShooting:
                animation.update_animation(last_direction)
                if animation.is_shooting_complete:
                    isShooting = False
                    animation.is_shooting = False
                    animation.is_shooting_complete = False

            else:
                idle_direction = "IR" if right else "IL"
                animation.update_animation(last_direction)

                                       

            animation.draw(screen, last_direction if isShooting else idle_direction, (char_x, base_y + sy))
        
        else:
            #if not isShooting:
                idle_direction = "IR" if right else "IL"
                #animation.update_animation(idle_direction)
                animation.draw(screen, last_direction, (350, base_y + sy))
                
            
            
        

     
        if not isJump:
            if keys[pygame.K_LEFT] and bg.scroll > 0:
                bg.update_scroll(-vel)
                last_direction = "WL"
                left = True
                right = False
                idle = False
                if not isShooting:
                    animation.update_animation(idle_direction)
                            
            
            elif keys[pygame.K_RIGHT] and bg.scroll < 5000 - width - vel:
                bg.update_scroll(vel)
                last_direction = "WR"
                left = False
                right = True
                idle = False
                if not isShooting:
                    animation.update_animation(idle_direction) 
                else: 
                    animation.update_animation(idle_direction)
            
            if not isShooting:
                animation.update_animation(idle_direction)
                                                                                                    #Check this code       
            else:
                animation.update_animation(idle_direction) 
                idle = True
            if idle:
                last_direction = "IR" if right else "IL"    
            
            if keys[pygame.K_UP]:
                isJump = True
                last_direction = "JR" if last_direction == "WR" else "JL"

        else:
            

            if jumpCount < -10:
                isJump = False
                jumpCount = 10
                sy = 0   

        for bullet in bullets[:]:
            bullet.update()
            bullet.draw(screen)   
            if bullet.x < 0 or bullet.x > SCREENWIDTH:
                bullets.remove(bullet)

        if health <= 1:
            run = False
       
        if bg.scroll >= 5000 - 800:
            level += 1
            if level > 3:
                level = 1
            bg = Plax_BG.ParallaxBackground(level)
            char_x = 300
            bg.scroll = 0
        
        
        if pygame.Rect(350, base_y + sy, width, height).colliderect(ammo_pickup.rect):
            ammo += 5
            ammo_pickup = AmmoPickup(500, 200)
        

        bg.draw_bg(screen)
        bg.draw_ground(screen)
        animation.draw(screen, last_direction, (350, base_y + sy))
        display_level(screen, level)
        display_health(screen, health)
        display_ammo_count(screen, ammo)
        
        
        if health <= 1:
            print("GAME OVER!")
            run = False
        pygame.display.flip()
    pass

if __name__ == "__main__":
    title_screen()
    main_game_loop()



pygame.quit(), 
'''