from matplotlib import animation
import pygame.display
import pygame.surface
import pygame.transform
import pygame
import pygame.sprite
import os
os.chdir('\\City Escape')
from pygame.locals import *

pygame.display.init()
SCREENWIDTH = 1344
SCREENHEIGHT = 756
pygame.init()
clock = pygame.time.Clock()
FPS = 60
screen = pygame.display.set_mode([SCREENWIDTH, SCREENHEIGHT])

#Character sprite sheets
char_WR_sprite_sheet = pygame.image.load('ch_1/char_walkR.png').convert_alpha()
char_SR_sprite_sheet = pygame.image.load('ch_1/char_shootR.png').convert_alpha()
char_RR_sprite_sheet = pygame.image.load('ch_1/char_runR.png').convert_alpha()
char_RLR_sprite_sheet = pygame.image.load('ch_1/char_reloadR.png').convert_alpha()
char_M1R_sprite_sheet = pygame.image.load('ch_1/char_m1R.png').convert_alpha()
char_M2R_sprite_sheet = pygame.image.load('ch_1/char_m2R.png').convert_alpha()
char_JR_sprite_sheet = pygame.image.load('ch_1/char_jumpR.png').convert_alpha()
char_IR_sprite_sheet = pygame.image.load('ch_1/char_idlR.png').convert_alpha()
char_HR_sprite_sheet = pygame.image.load('ch_1/char_hurtR.png').convert_alpha()
char_DR_sprite_sheet = pygame.image.load('ch_1/char_dieR.png').convert_alpha()

# zombie man sprite sheets
zombie_man_WR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Walk.png').convert_alpha()
zombie_man_IR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Idle.png').convert_alpha()
zombie_man_RR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Run.png').convert_alpha()
zombie_man_A1_sprite_sheet = pygame.image.load('enemy/Zombie Man/Attack_1.png').convert_alpha()
zombie_man_A2_sprite_sheet = pygame.image.load('enemy/Zombie Man/Attack_2.png').convert_alpha()
zombie_man_A3_sprite_sheet = pygame.image.load('enemy/Zombie Man/Attack_3.png').convert_alpha()
zombie_man_BR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Bite.png').convert_alpha()
zombie_man_HR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Hurt.png').convert_alpha()
zombie_man_DR_sprite_sheet = pygame.image.load('enemy/Zombie Man/Dead.png').convert_alpha()

# zombie woman sprite sheets
zombie_woman_WR_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Walk.png').convert_alpha()
zombie_woman_IR_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Idle.png').convert_alpha()
zombie_woman_RR_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Run.png').convert_alpha()
zombie_woman_A1_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Attack_1.png').convert_alpha()
zombie_woman_A2_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Attack_2.png').convert_alpha()
zombie_woman_A3_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Attack_3.png').convert_alpha()
zombie_woman_HR_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Hurt.png').convert_alpha()
zombie_woman_DR_sprite_sheet = pygame.image.load('enemy/Zombie Woman/Dead.png').convert_alpha()

# wild zombie sprite sheets
zombie_wild_WR_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Walk.png').convert_alpha()
zombie_wild_IR_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Idle.png').convert_alpha()
zombie_wild_RR_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Run.png').convert_alpha()
zombie_wild_A1_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Attack_1.png').convert_alpha()
zombie_wild_A2_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Attack_2.png').convert_alpha()
zombie_wild_A3_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Attack_3.png').convert_alpha()
zombie_wild_HR_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Hurt.png').convert_alpha()
zombie_wild_DR_sprite_sheet = pygame.image.load('enemy/Wild Zombie/Dead.png').convert_alpha()

class sprite_frame():
    def __init__(self, image):
        self.sheet = image

#Char 1 image capture
    def get_imageWR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
       
    frame_WR0 = get_imageWR(char_WR_sprite_sheet, 0, 128, 128, 3.5)
    frame_WR1 = get_imageWR(char_WR_sprite_sheet, 1, 128, 128, 3.5)
    frame_WR2 = get_imageWR(char_WR_sprite_sheet, 2, 128, 128, 3.5)
    frame_WR3 = get_imageWR(char_WR_sprite_sheet, 3, 128, 128, 3.5)
    frame_WR4 = get_imageWR(char_WR_sprite_sheet, 4, 128, 128, 3.5)
    frame_WR5 = get_imageWR(char_WR_sprite_sheet, 5, 128, 128, 3.5)
            
    def get_imageSR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        return image

    frame_SR0 = get_imageSR(char_SR_sprite_sheet, 0, 128, 128, 3.5)
    frame_SR1 = get_imageSR(char_SR_sprite_sheet, 1, 128, 128, 3.5)
    frame_SR2 = get_imageSR(char_SR_sprite_sheet, 2, 128, 128, 3.5)
    frame_SR3 = get_imageSR(char_SR_sprite_sheet, 3, 128, 128, 3.5)
    frame_SR4 = get_imageSR(char_SR_sprite_sheet, 4, 128, 128, 3.5)
    frame_SR5 = get_imageSR(char_SR_sprite_sheet, 5, 128, 128, 3.5)
    frame_SR6 = get_imageSR(char_SR_sprite_sheet, 6, 128, 128, 3.5)
    frame_SR7 = get_imageSR(char_SR_sprite_sheet, 7, 128, 128, 3.5)
    frame_SR8 = get_imageSR(char_SR_sprite_sheet, 8, 128, 128, 3.5)
    frame_SR9 = get_imageSR(char_SR_sprite_sheet, 9, 128, 128, 3.5)
    frame_SR10 = get_imageSR(char_SR_sprite_sheet, 10, 128, 128, 3.5)
    frame_SR11 = get_imageSR(char_SR_sprite_sheet, 11, 128, 128, 3.5)

    
    def get_imageRR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        return image

    frame_RR0 = get_imageRR(char_RR_sprite_sheet, 0, 128, 128, 3.5)
    frame_RR1 = get_imageRR(char_RR_sprite_sheet, 1, 128, 128, 3.5)
    frame_RR2 = get_imageRR(char_RR_sprite_sheet, 2, 128, 128, 3.5)
    frame_RR3 = get_imageRR(char_RR_sprite_sheet, 3, 128, 128, 3.5)
    frame_RR4 = get_imageRR(char_RR_sprite_sheet, 4, 128, 128, 3.5)
    frame_RR5 = get_imageRR(char_RR_sprite_sheet, 5, 128, 128, 3.5)
    frame_RR6 = get_imageRR(char_RR_sprite_sheet, 6, 128, 128, 3.5)
    frame_RR7 = get_imageRR(char_RR_sprite_sheet, 7, 128, 128, 3.5)

    
    def get_imageRLR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_RLR0 = get_imageRLR(char_RLR_sprite_sheet, 0, 128, 128, 3.5)
    frame_RLR1 = get_imageRLR(char_RLR_sprite_sheet, 1, 128, 128, 3.5)
    frame_RLR2 = get_imageRLR(char_RLR_sprite_sheet, 2, 128, 128, 3.5)
    frame_RLR3 = get_imageRLR(char_RLR_sprite_sheet, 3, 128, 128, 3.5)
    frame_RLR4 = get_imageRLR(char_RLR_sprite_sheet, 4, 128, 128, 3.5)
    frame_RLR5 = get_imageRLR(char_RLR_sprite_sheet, 5, 128, 128, 3.5)
    frame_RLR6 = get_imageRLR(char_RLR_sprite_sheet, 6, 128, 128, 3.5)
    frame_RLR7 = get_imageRLR(char_RLR_sprite_sheet, 7, 128, 128, 3.5)
    frame_RLR8 = get_imageRLR(char_RLR_sprite_sheet, 8, 128, 128, 3.5)
    frame_RLR9 = get_imageRLR(char_RLR_sprite_sheet, 9, 128, 128, 3.5)
    frame_RLR10 = get_imageRLR(char_RLR_sprite_sheet, 10, 128, 128, 3.5)
    frame_RLR11 = get_imageRLR(char_RLR_sprite_sheet, 11, 128, 128, 3.5)


    def get_imageM1R(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_M1R0 = get_imageM1R(char_M1R_sprite_sheet, 0, 128, 128, 3.5)
    frame_M1R1 = get_imageM1R(char_M1R_sprite_sheet, 1, 128, 128, 3.5)
    frame_M1R2 = get_imageM1R(char_M1R_sprite_sheet, 2, 128, 128, 3.5)
    frame_M1R3 = get_imageM1R(char_M1R_sprite_sheet, 3, 128, 128, 3.5)
    frame_M1R4 = get_imageM1R(char_M1R_sprite_sheet, 4, 128, 128, 3.5)
    frame_M1R5 = get_imageM1R(char_M1R_sprite_sheet, 5, 128, 128, 3.5)

    def get_imageM2R(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_M2R0 = get_imageM2R(char_M2R_sprite_sheet, 0, 128, 128, 3.5)
    frame_M2R1 = get_imageM2R(char_M2R_sprite_sheet, 1, 128, 128, 3.5)
    frame_M2R2 = get_imageM2R(char_M2R_sprite_sheet, 2, 128, 128, 3.5)


    def get_imageJR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_JR0 = get_imageJR(char_JR_sprite_sheet, 0, 128, 128, 3.5)
    frame_JR1 = get_imageJR(char_JR_sprite_sheet, 1, 128, 128, 3.5)
    frame_JR2 = get_imageJR(char_JR_sprite_sheet, 2, 128, 128, 3.5)
    frame_JR3 = get_imageJR(char_JR_sprite_sheet, 3, 128, 128, 3.5)
    frame_JR4 = get_imageJR(char_JR_sprite_sheet, 4, 128, 128, 3.5)
    frame_JR5 = get_imageJR(char_JR_sprite_sheet, 5, 128, 128, 3.5)
    frame_JR6 = get_imageJR(char_JR_sprite_sheet, 6, 128, 128, 3.5)
    frame_JR7 = get_imageJR(char_JR_sprite_sheet, 7, 128, 128, 3.5)
    frame_JR8 = get_imageJR(char_JR_sprite_sheet, 8, 128, 128, 3.5)
    frame_JR9 = get_imageJR(char_JR_sprite_sheet, 9, 128, 128, 3.5)
    frame_JR10 = get_imageJR(char_JR_sprite_sheet, 10, 128, 128, 3.5)

    def get_imageIR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_IR0 = get_imageIR(char_IR_sprite_sheet, 0, 128, 128, 3.5)
    frame_IR1 = get_imageIR(char_IR_sprite_sheet, 1, 128, 128, 3.5)
    frame_IR2 = get_imageIR(char_IR_sprite_sheet, 2, 128, 128, 3.5)
    frame_IR3 = get_imageIR(char_IR_sprite_sheet, 3, 128, 128, 3.5)
    frame_IR4 = get_imageIR(char_IR_sprite_sheet, 4, 128, 128, 3.5)
    frame_IR5 = get_imageIR(char_IR_sprite_sheet, 5, 128, 128, 3.5)

    def get_imageHR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_HR0 = get_imageHR(char_HR_sprite_sheet, 0, 128, 128, 3.5)
    frame_HR1 = get_imageHR(char_HR_sprite_sheet, 1, 128, 128, 3.5)

    def get_imageDR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image

    frame_DR0 = get_imageDR(char_DR_sprite_sheet, 0, 128, 128, 3.5)
    frame_DR1 = get_imageDR(char_DR_sprite_sheet, 1, 128, 128, 3.5)
    frame_DR2 = get_imageDR(char_DR_sprite_sheet, 2, 128, 128, 3.5)
    frame_DR3 = get_imageDR(char_DR_sprite_sheet, 3, 128, 128, 3.5)

#Zombie Man image capture
    def get_image_ZM_WR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_WR0 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_WR1 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_WR2 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_WR3 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_WR4 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 4, 96, 96, 5)
    frame_ZM_WR5 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 5, 96, 96, 5)
    frame_ZM_WR6 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 6, 96, 96, 5)
    frame_ZM_WR7 = get_image_ZM_WR(zombie_man_WR_sprite_sheet, 7, 96, 96, 5)

    def get_image_ZM_IR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_IR0 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_IR1 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_IR2 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_IR3 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_IR4 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 4, 96, 96, 5)
    frame_ZM_IR5 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 5, 96, 96, 5)
    frame_ZM_IR6 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 6, 96, 96, 5)
    frame_ZM_IR7 = get_image_ZM_IR(zombie_man_IR_sprite_sheet, 7, 96, 96, 5)

    def get_image_ZM_RR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_RR0 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_RR1 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_RR2 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_RR3 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_RR4 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 4, 96, 96, 5)
    frame_ZM_RR5 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 5, 96, 96, 5)
    frame_ZM_RR6 = get_image_ZM_RR(zombie_man_RR_sprite_sheet, 6, 96, 96, 5)

    def get_image_ZM_AR1(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_AR1_0 = get_image_ZM_AR1(zombie_man_A1_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_AR1_1 = get_image_ZM_AR1(zombie_man_A1_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_AR1_2 = get_image_ZM_AR1(zombie_man_A1_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_AR1_3 = get_image_ZM_AR1(zombie_man_A1_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_AR1_4 = get_image_ZM_AR1(zombie_man_A1_sprite_sheet, 4, 96, 96, 5)

    def get_image_ZM_AR2(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_AR2_0 = get_image_ZM_AR2(zombie_man_A2_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_AR2_1 = get_image_ZM_AR2(zombie_man_A2_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_AR2_2 = get_image_ZM_AR2(zombie_man_A2_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_AR2_3 = get_image_ZM_AR2(zombie_man_A2_sprite_sheet, 3, 96, 96, 5)

    def get_image_ZM_AR3(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_AR3_0 = get_image_ZM_AR3(zombie_man_A3_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_AR3_1 = get_image_ZM_AR3(zombie_man_A3_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_AR3_2 = get_image_ZM_AR3(zombie_man_A3_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_AR3_3 = get_image_ZM_AR3(zombie_man_A3_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_AR3_4 = get_image_ZM_AR3(zombie_man_A3_sprite_sheet, 4, 96, 96, 5)

    def get_image_ZM_BR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_BR0 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_BR1 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_BR2 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_BR3 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_BR4 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 4, 96, 96, 5)
    frame_ZM_BR5 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 5, 96, 96, 5)
    frame_ZM_BR6 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 6, 96, 96, 5)
    frame_ZM_BR7 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 7, 96, 96, 5)
    frame_ZM_BR8 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 8, 96, 96, 5)
    frame_ZM_BR9 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 9, 96, 96, 5)
    frame_ZM_BR10 = get_image_ZM_BR(zombie_man_BR_sprite_sheet, 10, 96, 96, 5)

    def get_image_ZM_HR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_HR_0 = get_image_ZM_HR(zombie_man_HR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_HR_1 = get_image_ZM_HR(zombie_man_HR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_HR_2 = get_image_ZM_HR(zombie_man_HR_sprite_sheet, 2, 96, 96, 5)

    def get_image_ZM_DR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZM_DR0 = get_image_ZM_DR(zombie_man_DR_sprite_sheet, 0, 96, 96, 5)
    frame_ZM_DR1 = get_image_ZM_DR(zombie_man_DR_sprite_sheet, 1, 96, 96, 5)
    frame_ZM_DR2 = get_image_ZM_DR(zombie_man_DR_sprite_sheet, 2, 96, 96, 5)
    frame_ZM_DR3 = get_image_ZM_DR(zombie_man_DR_sprite_sheet, 3, 96, 96, 5)
    frame_ZM_DR4 = get_image_ZM_DR(zombie_man_DR_sprite_sheet, 4, 96, 96, 5)

# ZOMBIE WOMAN IMAGE CAPTUE
    def get_image_ZW_WR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_WR0 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_WR1 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_WR2 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_WR3 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 3, 96, 96, 5)
    frame_ZW_WR4 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 4, 96, 96, 5)
    frame_ZW_WR5 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 5, 96, 96, 5)
    frame_ZW_WR6 = get_image_ZW_WR(zombie_woman_WR_sprite_sheet, 6, 96, 96, 5)


    def get_image_ZW_IR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_IR0 = get_image_ZW_IR(zombie_woman_IR_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_IR1 = get_image_ZW_IR(zombie_woman_IR_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_IR2 = get_image_ZW_IR(zombie_woman_IR_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_IR3 = get_image_ZW_IR(zombie_woman_IR_sprite_sheet, 3, 96, 96, 5)
    frame_ZW_IR4 = get_image_ZW_IR(zombie_woman_IR_sprite_sheet, 4, 96, 96, 5)


    def get_image_ZW_RR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_RR0 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_RR1 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_RR2 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_RR3 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 3, 96, 96, 5)
    frame_ZW_RR4 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 4, 96, 96, 5)
    frame_ZW_RR5 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 5, 96, 96, 5)
    frame_ZW_RR6 = get_image_ZW_RR(zombie_woman_RR_sprite_sheet, 6, 96, 96, 5)

    def get_image_ZW_AR1(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_AR1_0 = get_image_ZW_AR1(zombie_woman_A1_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_AR1_1 = get_image_ZW_AR1(zombie_woman_A1_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_AR1_2 = get_image_ZW_AR1(zombie_woman_A1_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_AR1_3 = get_image_ZW_AR1(zombie_woman_A1_sprite_sheet, 3, 96, 96, 5)


    def get_image_ZW_AR2(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_AR2_0 = get_image_ZW_AR2(zombie_woman_A2_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_AR2_1 = get_image_ZW_AR2(zombie_woman_A2_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_AR2_2 = get_image_ZW_AR2(zombie_woman_A2_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_AR2_3 = get_image_ZW_AR2(zombie_woman_A2_sprite_sheet, 3, 96, 96, 5)

    def get_image_ZW_AR3(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_AR3_0 = get_image_ZW_AR3(zombie_woman_A3_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_AR3_1 = get_image_ZW_AR3(zombie_woman_A3_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_AR3_2 = get_image_ZW_AR3(zombie_woman_A3_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_AR3_3 = get_image_ZW_AR3(zombie_woman_A3_sprite_sheet, 3, 96, 96, 5)

    def get_image_ZW_HR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_HR_0 = get_image_ZW_HR(zombie_woman_HR_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_HR_1 = get_image_ZW_HR(zombie_woman_HR_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_HR_2 = get_image_ZW_HR(zombie_woman_HR_sprite_sheet, 2, 96, 96, 5)

    def get_image_ZW_DR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_ZW_DR0 = get_image_ZW_DR(zombie_woman_DR_sprite_sheet, 0, 96, 96, 5)
    frame_ZW_DR1 = get_image_ZW_DR(zombie_woman_DR_sprite_sheet, 1, 96, 96, 5)
    frame_ZW_DR2 = get_image_ZW_DR(zombie_woman_DR_sprite_sheet, 2, 96, 96, 5)
    frame_ZW_DR3 = get_image_ZW_DR(zombie_woman_DR_sprite_sheet, 3, 96, 96, 5)
    frame_ZW_DR4 = get_image_ZW_DR(zombie_woman_DR_sprite_sheet, 4, 96, 96, 5)

# Wild Zombie image capture
    def get_image_WZ_WR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_WR0 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_WR1 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_WR2 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_WR3 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 3, 96, 96, 5)
    frame_WZ_WR4 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 4, 96, 96, 5)
    frame_WZ_WR5 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 5, 96, 96, 5)
    frame_WZ_WR6 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 6, 96, 96, 5)
    frame_WZ_WR7 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 4, 96, 96, 5)
    frame_WZ_WR8 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 5, 96, 96, 5)
    frame_WZ_WR9 = get_image_WZ_WR(zombie_wild_WR_sprite_sheet, 6, 96, 96, 5)

    def get_image_WZ_IR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_IR0 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_IR1 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_IR2 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_IR3 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 3, 96, 96, 5)
    frame_WZ_IR4 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 4, 96, 96, 5)
    frame_WZ_IR5 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 5, 96, 96, 5)
    frame_WZ_IR6 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 6, 96, 96, 5)
    frame_WZ_IR7 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 4, 96, 96, 5)
    frame_WZ_IR8 = get_image_WZ_IR(zombie_wild_IR_sprite_sheet, 5, 96, 96, 5)


    def get_image_WZ_RR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_RR0 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_RR1 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_RR2 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_RR3 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 3, 96, 96, 5)
    frame_WZ_RR4 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 4, 96, 96, 5)
    frame_WZ_RR5 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 5, 96, 96, 5)
    frame_WZ_RR6 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 6, 96, 96, 5)
    frame_WZ_RR7 = get_image_WZ_RR(zombie_wild_RR_sprite_sheet, 7, 96, 96, 5)

    def get_image_WZ_AR1(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_AR1_0 = get_image_WZ_AR1(zombie_wild_A1_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_AR1_1 = get_image_WZ_AR1(zombie_wild_A1_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_AR1_2 = get_image_WZ_AR1(zombie_wild_A1_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_AR1_3 = get_image_WZ_AR1(zombie_wild_A1_sprite_sheet, 3, 96, 96, 5)


    def get_image_WZ_AR2(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_AR2_0 = get_image_WZ_AR2(zombie_wild_A2_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_AR2_1 = get_image_WZ_AR2(zombie_wild_A2_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_AR2_2 = get_image_WZ_AR2(zombie_wild_A2_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_AR2_3 = get_image_WZ_AR2(zombie_wild_A2_sprite_sheet, 3, 96, 96, 5)

    def get_image_WZ_AR3(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_AR3_0 = get_image_WZ_AR3(zombie_wild_A3_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_AR3_1 = get_image_WZ_AR3(zombie_wild_A3_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_AR3_2 = get_image_WZ_AR3(zombie_wild_A3_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_AR3_3 = get_image_WZ_AR3(zombie_wild_A3_sprite_sheet, 3, 96, 96, 5)

    def get_image_WZ_HR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_HR_0 = get_image_WZ_HR(zombie_wild_HR_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_HR_1 = get_image_WZ_HR(zombie_wild_HR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_HR_2 = get_image_WZ_HR(zombie_wild_HR_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_HR_1 = get_image_WZ_HR(zombie_wild_HR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_HR_2 = get_image_WZ_HR(zombie_wild_HR_sprite_sheet, 2, 96, 96, 5)

    def get_image_WZ_DR(sheet, frame, width, height, scale):
        image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        
        return image
    frame_WZ_DR0 = get_image_WZ_DR(zombie_wild_DR_sprite_sheet, 0, 96, 96, 5)
    frame_WZ_DR1 = get_image_WZ_DR(zombie_wild_DR_sprite_sheet, 1, 96, 96, 5)
    frame_WZ_DR2 = get_image_WZ_DR(zombie_wild_DR_sprite_sheet, 2, 96, 96, 5)
    frame_WZ_DR3 = get_image_WZ_DR(zombie_wild_DR_sprite_sheet, 3, 96, 96, 5)
    frame_WZ_DR4 = get_image_WZ_DR(zombie_wild_DR_sprite_sheet, 4, 96, 96, 5)

'''

'''

pygame.quit()